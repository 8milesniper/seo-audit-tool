import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Check, X, Zap, Crown, Building, ArrowLeft, Star, TestTube } from 'lucide-react'
import { getPaymentUrl, isInTestMode } from '@/config/stripeConfig'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '@/contexts/AuthContext'
import { usePayment } from '@/contexts/PaymentContext'
import toast from 'react-hot-toast'

const PricingPage = () => {
  const [billingInterval, setBillingInterval] = useState<'monthly' | 'yearly'>('monthly')
  const { state: authState } = useAuth()
  const { createPayment } = usePayment()
  const navigate = useNavigate()

  const pricingTiers = [
    {
      id: 'pro',
      name: 'Pro Audit',
      description: 'Complete AI search readiness for serious businesses',
      price: 47,
      yearlyPrice: 47,
      icon: Star,
      features: [
        'Everything in Free',
        'Complete AI search readiness audit',
        'Google SGE optimization analysis',
        'ChatGPT Search optimization',
        'Perplexity AI readiness check',
        'Bing Copilot optimization',
        'Voice search optimization',
        'Advanced E-E-A-T analysis',
        'Complete schema markup audit',
        'Professional branded PDF report',
        'Priority email support',
        'Competitor comparison'
      ],
      limitations: [],
      cta: 'Get Pro Audit',
      popular: true,
      color: 'amber',
      oneTime: true
    },
    {
      id: 'agency',
      name: 'Agency Plan',
      description: 'White-label solution for agencies and enterprises',
      price: 197,
      yearlyPrice: 1970, // 10 months price for yearly
      icon: Building,
      features: [
        'Everything in Pro',
        'Unlimited audits',
        'White-label PDF reports',
        'Custom branding & logos',
        'Bulk audit processing',
        'Agency dashboard',
        'Client management system',
        'API access',
        'Priority phone support',
        'Training materials',
        'Reseller opportunities',
        'Custom domain option',
        'Advanced analytics'
      ],
      limitations: [],
      cta: 'Start Agency Plan',
      popular: false,
      color: 'purple'
    }
  ]

  const handleSelectPlan = async (tier: typeof pricingTiers[0]) => {
    // ROBUST test mode detection - check multiple sources
    const adminTestMode = localStorage.getItem('admin_test_mode') === 'true'
    const testModeDetected = isInTestMode() || adminTestMode
    
    console.log('Test mode check:', {
      adminTestMode,
      isInTestMode: isInTestMode(),
      finalTestMode: testModeDetected
    })
    
    if (testModeDetected) {
      // In test mode, redirect to payment success page to simulate payment
      if (tier.id === 'pro') {
        toast.success('🧪 Test Mode: Simulating $47 payment...')
        setTimeout(() => {
          window.location.href = '/payment-success?amount=47&email=test@example.com&name=Test Customer'
        }, 1500)
        return
      }
      if (tier.id === 'agency') {
        toast.success('🧪 Test Mode: Simulating $197 payment...')
        setTimeout(() => {
          window.location.href = '/payment-success?amount=197&email=test@example.com&name=Test Customer'
        }, 1500)
        return
      }
    }

    // Live mode - redirect to actual Stripe payment links
    if (tier.id === 'pro') {
      // $47 SEO Audit - redirect to Stripe
      window.location.href = getPaymentUrl('audit')
      return
    }

    if (tier.id === 'agency') {
      // $197/month Enterprise - redirect to Stripe  
      window.location.href = getPaymentUrl('enterprise')
      return
    }

    // Fallback for any other plans
    toast.error('Please contact support for this plan')
  }

  const getPrice = (tier: typeof pricingTiers[0]) => {
    return billingInterval === 'yearly' ? tier.yearlyPrice : tier.price
  }

  const getSavings = (tier: typeof pricingTiers[0]) => {
    if (tier.yearlyPrice === tier.price || tier.oneTime) return 0
    return Math.round(((tier.price * 12 - tier.yearlyPrice) / (tier.price * 12)) * 100)
  }

  const getCardStyle = (tier: typeof pricingTiers[0]) => {
    if (tier.popular) {
      return 'border-amber-500 scale-105 shadow-xl shadow-amber-500/20'
    }
    return 'border-slate-700 hover:border-slate-600'
  }

  const getButtonStyle = (tier: typeof pricingTiers[0]) => {
    if (tier.popular) {
      return 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-black'
    }
    if (tier.id === 'free') {
      return 'bg-slate-700 hover:bg-slate-600 text-white'
    }
    return 'bg-purple-600 hover:bg-purple-700 text-white'
  }

  return (
    <div className="min-h-screen py-12 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <Button
            variant="ghost"
            className="mb-6 text-white hover:bg-white/10"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Choose Your AI Search Advantage
          </h1>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto mb-8">
            Get ready for the future of search with the world's first AI search optimization platform. 
            Join thousands of businesses already preparing for 2025.
          </p>

          {/* ENHANCED Test Mode Indicator */}
          {(isInTestMode() || localStorage.getItem('admin_test_mode') === 'true') && (
            <div className="mb-8 max-w-4xl mx-auto">
              <div className="bg-gradient-to-r from-green-500/30 to-blue-500/30 border-2 border-green-500/50 rounded-xl p-6 shadow-lg">
                <div className="flex items-center justify-center gap-3 text-green-300 mb-2">
                  <TestTube className="w-8 h-8" />
                  <span className="font-bold text-2xl">🧪 TEST MODE ACTIVE</span>
                </div>
                <p className="text-lg text-white text-center font-semibold">
                  ✅ NO REAL PAYMENTS - All transactions will be simulated
                </p>
                <p className="text-sm text-green-200 mt-2 text-center">
                  Perfect for testing the customer experience without any charges!
                </p>
              </div>
            </div>
          )}

          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4 mb-8">
            <span className={`text-sm ${billingInterval === 'monthly' ? 'text-white' : 'text-slate-400'}`}>
              Monthly
            </span>
            <button
              onClick={() => setBillingInterval(billingInterval === 'monthly' ? 'yearly' : 'monthly')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                billingInterval === 'yearly' ? 'bg-amber-500' : 'bg-slate-600'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  billingInterval === 'yearly' ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
            <span className={`text-sm ${billingInterval === 'yearly' ? 'text-white' : 'text-slate-400'}`}>
              Yearly
            </span>
            {billingInterval === 'yearly' && (
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                Save up to 20%
              </Badge>
            )}
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {pricingTiers.map((tier) => (
            <Card key={tier.id} className={`relative bg-slate-800/50 ${getCardStyle(tier)} transition-all duration-300`}>
              {tier.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-amber-500 text-black font-semibold">
                  MOST POPULAR
                </Badge>
              )}

              <CardHeader className="text-center pb-6">
                <div className="w-12 h-12 mx-auto mb-4 bg-slate-700 rounded-lg flex items-center justify-center">
                  <tier.icon className={`w-6 h-6 ${tier.popular ? 'text-amber-400' : 'text-slate-400'}`} />
                </div>
                <CardTitle className="text-2xl text-white">{tier.name}</CardTitle>
                <CardDescription className="text-slate-400">{tier.description}</CardDescription>
                
                <div className="mt-4">
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-white">${getPrice(tier)}</span>
                    {!tier.oneTime && tier.id !== 'free' && (
                      <span className="text-slate-400 ml-1">
                        /{billingInterval === 'yearly' ? 'year' : 'month'}
                      </span>
                    )}
                    {tier.oneTime && (
                      <span className="text-slate-400 ml-1">one-time</span>
                    )}
                  </div>
                  {getSavings(tier) > 0 && (
                    <p className="text-green-400 text-sm mt-1">
                      Save {getSavings(tier)}% with yearly billing
                    </p>
                  )}
                </div>
              </CardHeader>

              <CardContent>
                <Button 
                  className={`w-full mb-6 ${getButtonStyle(tier)}`}
                  onClick={() => handleSelectPlan(tier)}
                  disabled={authState.user?.plan === tier.id}
                >
                  {authState.user?.plan === tier.id ? 'Current Plan' : tier.cta}
                </Button>

                <div className="space-y-4">
                  <div>
                    <h4 className="text-white font-semibold mb-3">What's included:</h4>
                    <ul className="space-y-2">
                      {tier.features.map((feature, index) => (
                        <li key={index} className="flex items-start space-x-3">
                          <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                          <span className="text-slate-300 text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {tier.limitations.length > 0 && (
                    <div>
                      <h4 className="text-slate-400 font-semibold mb-3">Not included:</h4>
                      <ul className="space-y-2">
                        {tier.limitations.map((limitation, index) => (
                          <li key={index} className="flex items-start space-x-3">
                            <X className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                            <span className="text-slate-400 text-sm">{limitation}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-8">
            Frequently Asked Questions
          </h2>
          <div className="grid gap-6">
            {[
              {
                q: "What makes this different from other SEO tools?",
                a: "We're the ONLY platform that analyzes your readiness for AI search engines like Google SGE, ChatGPT Search, Perplexity AI, and Bing Copilot. While others focus on traditional SEO, we prepare you for the future of search."
              },
              {
                q: "Can I cancel my subscription anytime?",
                a: "Yes, you can cancel your Agency plan subscription at any time. Pro audits are one-time payments with no recurring charges."
              },
              {
                q: "Do you offer white-label solutions?",
                a: "Yes! Our Agency plan includes full white-label capabilities, custom branding, and reseller opportunities for agencies and consultants."
              },
              {
                q: "What AI search engines do you analyze?",
                a: "We analyze readiness for Google SGE (Search Generative Experience), ChatGPT Search, Perplexity AI, Bing Copilot, and other emerging AI-powered search platforms."
              },
              {
                q: "Is there a money-back guarantee?",
                a: "Yes, we offer a 30-day money-back guarantee on all paid plans. If you're not satisfied, we'll refund your payment."
              }
            ].map((faq, index) => (
              <Card key={index} className="bg-slate-800/50 border-slate-700">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-white mb-3">{faq.q}</h3>
                  <p className="text-slate-300">{faq.a}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16 p-8 bg-gradient-to-r from-amber-500/20 to-amber-600/20 border border-amber-500/30 rounded-lg">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Dominate AI Search?
          </h2>
          <p className="text-xl text-amber-200 mb-6">
            Join thousands of businesses already preparing for the future of search
          </p>
          <Button 
            size="lg"
            className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-black font-bold"
            onClick={() => navigate('/')}
          >
            Start Free Audit Now
          </Button>
        </div>
      </div>
    </div>
  )
}

export default PricingPage