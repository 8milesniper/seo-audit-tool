// Stripe Configuration - Switch between Test and Live modes

export interface StripeConfig {
  mode: 'test' | 'live'
  auditPrice: string // $47 payment link
  enterprisePrice: string // $197 payment link
}

// Check if we're in development/test mode
const isTestMode = () => {
  try {
    // PRIORITY 1: Check localStorage for admin test mode
    const adminTestMode = localStorage.getItem('admin_test_mode') === 'true'
    if (adminTestMode) {
      console.log('🧪 Test mode ACTIVE via admin panel')
      return true
    }
    
    // PRIORITY 2: Check if URL contains localhost or test domain
    const isDevelopment = window.location.hostname === 'localhost' || 
                         window.location.hostname.includes('test') ||
                         window.location.hostname.includes('staging')
    if (isDevelopment) {
      console.log('🧪 Test mode ACTIVE via development environment')
      return true
    }
    
    console.log('💰 LIVE mode - real payments will be processed')
    return false
  } catch (error) {
    console.error('Error checking test mode:', error)
    // Fail safe - default to test mode if there's an error
    return true
  }
}

// Stripe Configuration
export const getStripeConfig = (): StripeConfig => {
  if (isTestMode()) {
    return {
      mode: 'test',
      // TODO: Replace these with your Stripe TEST payment links
      auditPrice: 'https://buy.stripe.com/test_XXXXXX', // Replace with test link
      enterprisePrice: 'https://buy.stripe.com/test_YYYYYY', // Replace with test link
    }
  } else {
    return {
      mode: 'live',
      // Your current LIVE payment links
      auditPrice: 'https://buy.stripe.com/00w3cx0gsgl87oI8lL0co00',
      enterprisePrice: 'https://buy.stripe.com/fZu3cxe7i0ma7oIfOd0co01',
    }
  }
}

// Helper function to get payment URL
export const getPaymentUrl = (tier: 'audit' | 'enterprise'): string => {
  const config = getStripeConfig()
  
  if (tier === 'audit') {
    return config.auditPrice
  } else {
    return config.enterprisePrice
  }
}

// Helper function to check if we're in test mode
export const isInTestMode = (): boolean => {
  return getStripeConfig().mode === 'test'
}
